'Query Server for drive details
For sCount = 1 to UBound(ServerList)
	strComputer = ServerList(sCount)
	wscript.echo strComputer
	
	'Start the html table
    strHTML = strHTML & "<table width='50%'><tbody>" & vbcrlf 
    strHTML = strHTML & "<tr bgcolor='#CCCCCC'>" & vbcrlf 
    strHTML = strHTML & "<td width='50%' align='center' colSpan=6><font face='tahoma' color='#003399' size='2'><strong>" & StrComputer & "</strong></font></td>" & vbcrlf 
    strHTML = strHTML & "</tr>" & vbcrlf 
	strHTML = strHTML & "<tr bgcolor=#CCCCCC>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Type</td>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Drive / Mount</td>" & vbcrlf
	strHTML = strHTML & "<td width='20%' align='center'>Total Capacity (in GB)</td>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Used Capacity (in GB)</td>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Free Space (in GB)</td>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Freespace %</td>" & vbcrlf 
    strHTML = strHTML & "</tr>" & vbcrlf 
	
	'**FIX 1: Reset variables and objects for each server**
	Set objWMIService = Nothing
	Set colDisks = Nothing
	Set colItems = Nothing
	strMessage = ""
	
	'use WMI to get the disk information
	on error resume next
    Set objWMIService = GetObject("winmgmts:\\" & strComputer & "\root\cimv2") 
    if err.number <> 0 Then 
		strMessage = "WMI Error Connection to Server " & err.number & " " & err.description & vbcrlf
		err.clear
	Else
		Set colDisks = objWMIService.ExecQuery("Select * from Win32_LogicalDisk Where DriveType = " & HARD_DISK & "") 
		if err.number <> 0 Then 
			strMessage = "WMI Error querying disks " & err.number & " " & err.description & vbcrlf
			err.clear
		End If
	End If
	on error goto 0
	
	If Len(strMessage) > 0 Then
		strHTML = strHTML & "<tr>" & vbcrlf 
		strHTML = strHTML & "<td width='50%' colSpan=6>" & strMessage & "&nbsp;</td>" & vbcrlf 
		strHTML = strHTML & "</tr>" & vbcrlf
		strMessage = ""
	**'FIX 2: Only process if we have a valid colDisks object**
	ElseIf Not (colDisks Is Nothing) Then
		'Starting the loop to gather values from all Hard Drives 
		For Each objDisk in colDisks 
			If IsNull(objDisk.FreeSpace) Then

			Else
				'Get the data
				strMessage = ""
				FrPercent = ""
				FrSpace = ""
				TotSpace = ""
				UsSpace = ""
				Drv = ""
				TotSpace=Round(((objDisk.Size)/1073741824),2) 
				FrSpace=Round(objDisk.FreeSpace/1073741824,2) 
				FrPercent=Round((FrSpace / TotSpace)*100,0) 
				UsSpace=Round((TotSpace - FrSpace),2) 
				Drv=objDisk.DeviceID 
				
				'Check if today's data already exist and skip if true
				strSQL = "SELECT * FROM DiskSpaceHistory WHERE RunDate = '" & year(strRunDateString) & "-" & Month(strRunDateString) & "-" & Day(strRunDateString) & " 00:00:00' and ServerName = '" & lcase(strComputer) & "' and Drive = '" & Drv & "'"
				If WriteDB("AJ2.su.lan\SQL2019_DEV", "dbaUtilities", strSQL) < 1 Then
					'Write data to history database.
					If LEN(Drv) > 0 Then
						strSQL = "INSERT INTO DiskSpaceHistory (RunDate,ServerName,Drive,TotalSpace,UsedSpace,FreeSpace,Type)VALUES("
						strSQL = strSQL & "'" & year(strRunDateString) & "-" & Month(strRunDateString) & "-" & Day(strRunDateString) & " 00:00:00'"
						strSQL = strSQL & ",'" & lcase(strComputer) & "'"
						strSQL = strSQL & ",'" & Drv & "'"
						strSQL = strSQL & "," & TotSpace 
						strSQL = strSQL & "," & UsSpace
						strSQL = strSQL & "," & FrSpace
						strSQL = strSQL & ",'Drive'"
						strSQL = strSQL & ")"
						WriteDB "AJ2.su.lan\SQL2019_DEV", "dbaUtilities", strSQL
					End If
				End if
				
				
				'Build the next row in the html table
				If FrPercent > 20 Then 
					Green = Green + 1
					strHTML = strHTML & "<tr><td align=center>Drive</td><td align=left>" & Drv & "</td><td align=right>" & TotSpace & "</td><td align=right>" & UsSpace & "</td><td align=right>" & FrSpace & "</td><td BGCOLOR='#00FF00' align=right>" & FrPercent & "%" &"</td></tr>" 
				ElseIf FrPercent < 10 Then 
					If (Drv = "Z:") Then   'Don't increment Red Counter and just use light grey.  We don't care about Z: drive
						strHTML = strHTML & "<tr><td align=center>Drive</td><td align=left>" & Drv & "</td><td align=right>" & TotSpace & "</td><td align=right>" & UsSpace & "</td><td align=right>" & FrSpace & "</td><td bgcolor='#DCDCDC' align=right>" & FrPercent & "%" &"</td></tr>" 
					Else
						Red = Red + 1
						strHTML = strHTML & "<tr><td align=center>Drive</td><td align=left>" & Drv & "</td><td align=right>" & TotSpace & "</td><td align=right>" & UsSpace & "</td><td align=right>" & FrSpace & "</td><td bgcolor='#FF0000' align=right>" & FrPercent & "%" &"</td></tr>" 
					End If
				Else 
					Yellow = Yellow + 1
					strHTML = strHTML & "<tr><td align=center>Drive</td><td align=left>" & Drv & "</td><td align=right>" & TotSpace & "</td><td align=right>" & UsSpace & "</td><td align=right>" & FrSpace & "</td><td bgcolor='#FBB917' align=right>" & FrPercent & "%" &"</td></tr>" 
				End If 
			End If
		Next 
	End IF
	
	'**FIX 3: Reset for volume query**
	strMessage = ""
	
	'use WMI to get the volume information
	on error resume next
	if Not (objWMIService Is Nothing) Then
		Set colItems = objWMIService.ExecQuery("SELECT * FROM Win32_Volume where DriveLetter IS NULL",,48) 
		if err.number <> 0 Then 
			strMessage = "WMI Error querying volumes " & err.number & " " & err.description & vbcrlf
			err.clear
		End If
	Else
		strMessage = "WMI Service not available for volume query" & vbcrlf
	End If
	on error goto 0
	
	If Len(strMessage) > 0 Then
		strHTML = strHTML & "<tr>" & vbcrlf 
		strHTML = strHTML & "<td width='50%' colSpan=6>" & strMessage & "&nbsp;</td>" & vbcrlf 
		strHTML = strHTML & "</tr>" & vbcrlf
		strMessage = ""
	**'FIX 4: Only process if we have a valid colItems object**
	ElseIf Not (colItems Is Nothing) Then
		'Starting the loop to gather values from all volumes 
		For Each objItem in colItems 
			If IsNull(objItem.FreeSpace) Then
				 
			Else
				'Get the data
				strMessage = ""
				FrPercent = ""
				FrSpace = ""
				TotSpace = ""
				UsSpace = ""
				Drv = ""
				FrPercent = round(objItem.FreeSpace / objItem.Capacity * 100)
				FrSpace = round(((objItem.FreeSpace/1024)/1024/1024),2)
				TotSpace = round(((objItem.Capacity/1024)/1024)/1024,2)
				UsSpace = round(TotSpace - FrSpace,2)
				Drv = objItem.Caption
				
				If Left(Drv,2) <> "\\" AND LEN(Drv) > 2 then
					'Check if today's data already exist and skip if true
					strSQL = "SELECT * FROM DiskSpaceHistory WHERE RunDate = '" & year(strRunDateString) & "-" & Month(strRunDateString) & "-" & Day(strRunDateString) & " 00:00:00' and ServerName = '" & lcase(strComputer) & "' and Drive = '" & Drv & "'"
					If WriteDB("AJ2.su.lan\SQL2019_DEV", "dbaUtilities", strSQL) < 1 Then
						'Write data to history database.
						If LEN(Drv) > 0 Then
							strSQL = "INSERT INTO DiskSpaceHistory (RunDate,ServerName,Drive,TotalSpace,UsedSpace,FreeSpace,Type)VALUES("
							strSQL = strSQL & "'" & year(strRunDateString) & "-" & Month(strRunDateString) & "-" & Day(strRunDateString) & " 00:00:00'"
							strSQL = strSQL & ",'" & lcase(strComputer) & "'"
							strSQL = strSQL & ",'" & Drv & "'"
							strSQL = strSQL & "," & TotSpace 
							strSQL = strSQL & "," & UsSpace
							strSQL = strSQL & "," & FrSpace
							strSQL = strSQL & ",'Mount'"
							strSQL = strSQL & ")"
							WriteDB "AJ2.su.lan\SQL2019_DEV", "dbaUtilities", strSQL
						End If
					End if
			
					If FrPercent > 20 Then 
						Green = Green + 1
						strHTML = strHTML & "<tr><td align=center>Mount</td><td align=left>" & Drv & "</td><td align=right>" & TotSpace & "</td><td align=right>" & UsSpace & "</td><td align=right>" & FrSpace & "</td><td BGCOLOR='#00FF00' align=right>" & FrPercent & "%" &"</td></tr>" 
					ElseIf FrPercent < 10 Then 
						If Instr( 1, Drv, "\TempDB", vbTextCompare ) > 0 And FrPercent > 5 Then  
							'Don't increment Red Counter and just use light grey.  TempDB Drives are mostly filled, all is well if above 5%.
							strHTML = strHTML & "<tr><td align=center>Mount</td><td align=left>" & Drv & "</td><td align=right>" & TotSpace & "</td><td align=right>" & UsSpace & "</td><td align=right>" & FrSpace & "</td><td bgcolor='DCDCDC' align=right>" & FrPercent & "%" &"</td></tr>" 
						Else
							Red = Red + 1
							strHTML = strHTML & "<tr><td align=center>Mount</td><td align=left>" & Drv & "</td><td align=right>" & TotSpace & "</td><td align=right>" & UsSpace & "</td><td align=right>" & FrSpace & "</td><td bgcolor='#FF0000' align=right>" & FrPercent & "%" &"</td></tr>" 
						End If
					Else 
						Yellow = Yellow + 1
						strHTML = strHTML & "<tr><td align=center>Mount</td><td align=left>" & Drv & "</td><td align=right>" & TotSpace & "</td><td align=right>" & UsSpace & "</td><td align=right>" & FrSpace & "</td><td bgcolor='#FBB917' align=right>" & FrPercent & "%" &"</td></tr>" 
					End If 
				End IF
			End If
		Next
	End If
	'Finish the html table
    strHTML = strHTML & "</body></table><br>" & vbcrlf 
Next