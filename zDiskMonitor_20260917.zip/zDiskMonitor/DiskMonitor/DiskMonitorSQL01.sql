
--USE [MIS_Admins]
USE sys_admin ;
GO

/****** Object:  Table [dbo].[DiskSpaceHistory]    Script Date: 10/30/2020 5:41:04 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DiskSpaceHistory](
	[RunDate] [datetime2](2) NOT NULL,
	[ServerName] [varchar](30) NOT NULL,
	[Drive] [varchar](40) NOT NULL,
	[TotalSpace] [decimal](9, 3) NOT NULL,
	[UsedSpace] [decimal](9, 3) NOT NULL,
	[FreeSpace] [decimal](9, 3) NOT NULL,
	[Type] [varchar](20) NULL,
	[ID] [int] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_DiskSpaceHistory] PRIMARY KEY CLUSTERED 
(
	[RunDate] ASC,
	[ServerName] ASC,
	[Drive] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON
 , DATA_COMPRESSION = PAGE) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[DiskSpaceHistory] ADD  DEFAULT ((0)) FOR [TotalSpace]
GO
ALTER TABLE [dbo].[DiskSpaceHistory] ADD  DEFAULT ((0)) FOR [UsedSpace]
GO
ALTER TABLE [dbo].[DiskSpaceHistory] ADD  DEFAULT ((0)) FOR [FreeSpace]
GO
--Command(s) completed successfully.





USE sys_admin;
GO

/****** Object:  Table [dbo].[DiskSpaceThreshold]    Script Date: 10/30/2020 5:41:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DiskSpaceThreshold](
	[ServerName] [varchar](25) NULL,
	[Drive] [varchar](25) NULL,
	[FreeSpaceThresholdProportion] [decimal](4, 3) NULL
) 
ON [PRIMARY]
WITH (DATA_COMPRESSION = PAGE)

GO

SET ANSI_PADDING OFF
GO
--Command(s) completed successfully.


USE sys_admin;
go
SELECT d.* FROM DiskSpaceHistory d
WHERE ID = (SELECT MAX(ID) FROM DiskSpaceHistory d2 
			WHERE d2.ServerName = d.ServerName AND d2.Drive = d.Drive );
go




USE [msdb]
GO

/****** Object:  Job [_dly_0600_DiskMonitor]    Script Date: 10/30/2020 9:12:43 PM ******/
--EXEC msdb.dbo.sp_delete_job @job_id=N'00a6e0b7-d86d-454b-aef1-ab6e3909371a', @delete_unused_schedule=1
EXEC msdb.dbo.sp_delete_job @job_name = '_dly_0600_DiskMonitor', @delete_unused_schedule=1 ;
GO

/****** Object:  Job [_dly_0600_DiskMonitor]    Script Date: 10/30/2020 9:12:43 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 10/30/2020 9:12:43 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'_dly_0600_DiskMonitor', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'UBOC-AD\svc_s13_db_sqlagnt_p', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check that this instance is the Primary node, quit if not]    Script Date: 10/30/2020 9:12:43 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check that this instance is the Primary node, quit if not', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF (sys.fn_hadr_is_primary_replica(''UBSP_Content_CL_Bi'') = 0)
begin
   RAISERROR(''***QUIT JOB***, NOT PRIMARY NODE.'', 16, 1) ;
end
ELSE
begin
   PRINT ''Continue Job, this is the PRIMARY Node'' ;
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DiskSpace.vbs]    Script Date: 10/30/2020 9:12:43 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DiskSpace.vbs', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'C:\Windows\SysWOW64\cscript.exe "D:\Scripts\DiskMonitor\DiskSpace.vbs" "D:\Scripts\DiskMonitor\S13_Server_List.txt"', 
		@output_file_name=N'D:\SQLAgent_Output\S13\_dly_0600_DiskMonitor\Step01_DiskSpace_OUT.txt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'0600_Daily', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20201030, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'fbefe7f5-0bc8-4f70-97f1-4dbf39dd6587'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


