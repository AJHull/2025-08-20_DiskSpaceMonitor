strComputer = "SQL2017.su.lan"  '"aj2.su.lan"
'Set objWMIService = GetObject("winmgmts:" & "{impersonationLevel=impersonate}!\\" & strComputer & "\root\cimv2")
Set objWMIService = GetObject("winmgmts:\\" & strComputer & "\root\cimv2")
Set colProcessList = objWMIService.ExecQuery ("Select * from Win32_Process")

strProcessList = ""
iProcessCount = 0
For Each objProcess in colProcessList
    'Wscript.Echo "Process: " & objProcess.Name 
	iProcessCount = iProcessCount + 1
	strProcessList = strProcessList & vbcrlf & "Process " & CStr(iProcessCount) & ": " & objProcess.Name 
Next
Wscript.Echo strProcessList
