# Grant-BatchLogonRight.ps1
# Simple script to grant "Log on as batch job" right

param(
    [string]$ServiceAccount,
    [string]$ComputerName = $env:COMPUTERNAME
)

$ErrorActionPreference = 'Stop'
Write-Host "PARAMs:"
Write-Host "  ServiceAccount: $ServiceAccount"
Write-Host "  ComputerName  : $ComputerName"

# Run remotely
Write-Host "Processing remote server: $ComputerName"
$successTestConnection = Test-Connection $ComputerName -Count 1 -Quiet
if ($successTestConnection) {
	$success = Invoke-Command -ComputerName $ComputerName -ScriptBlock {
		param($Account)
		
		# Get the account SID
		$account = New-Object System.Security.Principal.NTAccount($Account)
		$sid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value

		# Create temp files
		$export = "C:\export_$ComputerName.inf"
		$import = "C:\import_$ComputerName.inf"

		# Export current policy
		secedit /export /cfg $export /quiet

		# Read the file
		$content = Get-Content $export

		# Find the batch logon line or add it
		$found = $false
		for ($i = 0; $i -lt $content.Length; $i++) {
			if ($content[$i] -match "SeBatchLogonRight") {
				if ($content[$i] -notlike "*$sid*") {
					$content[$i] = $content[$i] + ",*$sid"
				}
				$found = $true
				break
			}
		}

		# Add new line if not found
		if (-not $found) {
			Write-Host "$ServiceAccount on $ComputerName did not originally have log on as batch job permissions.  Adding now:"
			$content += "SeBatchLogonRight = *$sid"
		}
		else {
			Write-Host "$ServiceAccount on $ComputerName already has log on as batch job permissions."
		}

		# Write and import
		$content | Out-File $import -Encoding Unicode
		secedit /configure /db $env:windir\security\local.sdb /cfg $import /quiet

		# Cleanup
		# Remove-Item $export, $import

		#return "SUCCESS remote server: $ComputerName"
		
		
	} -ArgumentList $ServiceAccount
	
	if ($success) {
		Write-Host "$ComputerName completed successfully" -ForegroundColor Green
		#$successCount++
	} else {
		Write-Host "$ComputerName failed" -ForegroundColor Red
	}
	#Write-Host "Done. $ServiceAccount can now log on as batch job on $ComputerName."
} else {
	Write-Warning "Cannot reach server: $ComputerName"
}
