cscript DiskSpace.vbs CL_SQL9_List.txt
cscript DiskSpace.vbs CL_Server_List.txt
cscript DiskSpace.vbs CL_SP_TST_Server_List.txt
cscript DiskSpace.vbs CL_SP_PRD_Server_List.txt
cscript DiskSpace.vbs CL_SP_DR_Server_List.txt
cscript DiskSpace.vbs CL_SP_DEV_Server_List.txt
cscript DiskSpace.vbs CL_Radar_Server_List.txt
cscript DiskSpace.vbs "CL_Radar_Server_List - SQL.txt"
cscript DiskSpace.vbs CL_DataMart_Server_List.txt