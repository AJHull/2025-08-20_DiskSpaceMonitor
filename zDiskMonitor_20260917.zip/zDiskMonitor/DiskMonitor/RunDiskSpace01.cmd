@echo BEGIN script RunDiskSpace01.cmd %DATE% %TIME%
cscript DiskSpace.vbs "SUI_Server_List.txt"
REM cscript DiskSpace.vbs "SUI_Custom_List01.txt"
@echo END script RunDiskSpace01.cmd %DATE% %TIME%