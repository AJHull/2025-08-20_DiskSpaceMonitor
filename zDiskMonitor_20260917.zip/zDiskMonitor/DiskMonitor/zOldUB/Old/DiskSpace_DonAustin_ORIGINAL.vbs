'Debugging Section and Flags
DebugFlag = True
SQLDebugflg = False
If DebugFlag Then
	on error goto 0
Else
	on error resume next
End If

'get the script command line args
Set objArgs = Wscript.Arguments
if objArgs.Count < 1 then wscript.quit
strFileName = objArgs(0)
 
'Declaring the variables 
strRunDateString = now()
Const ForAppending = 8 
Const HARD_DISK = 3 
Const ForReading = 1 
Dim ServerList()
Set WshShell = CreateObject("WScript.Shell")
strCurDir    = WshShell.CurrentDirectory
strLogFile = "Logs\" & Left(Wscript.ScriptName,instrrev(Wscript.ScriptName,".")) & strRunDateString & ".log"
Set objFSO = CreateObject("Scripting.FileSystemObject") 
Set SrvList = objFSO.OpenTextFile(strFileName, ForReading) 
strFromSMTPServer = "smtp.uboc.com"
strFromEmailAddress = "donald.austin@unionbank.com"
strToEmailAddress = ""
strMessageMail = ""
strEmailAttachment = ""
Green = 0
Yellow = 0
Red = 0 
i = 0 

'Reading the config file provided by the command-line Report_Title/EmailList/Server_Names for report generation 
Redim ServerList(0)
ServerList(0) = SrvList.Readline 
strReportTitle = ServerList(0)
strToEmailAddress = SrvList.Readline
strEmailSubject = "DiskSpace Checks " & ServerList(0)
Do Until SrvList.AtEndOfStream 
	Redim Preserve ServerList(UBound(ServerList) + 1)
    ServerList(UBound(ServerList)) = SrvList.Readline 
Loop 

'Initializing the HTML Tags for better formatting 
strHTML = "<html>" & vbcrlf
strHTML = strHTML & "<head>" & vbcrlf 
strHTML = strHTML & "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>" & vbcrlf 
strHTML = strHTML & "<title>" & strReportTitle & "</title>" & vbcrlf 
strHTML = strHTML & "<style type='text/css'>" & vbcrlf 
strHTML = strHTML & "<!--" & vbcrlf 
strHTML = strHTML & "td {" & vbcrlf 
strHTML = strHTML & "font-family: Tahoma;" & vbcrlf 
strHTML = strHTML & "font-size: 11px;" & vbcrlf 
strHTML = strHTML & "border-top: 1px solid #999999;" & vbcrlf 
strHTML = strHTML & "border-right: 1px solid #999999;" & vbcrlf 
strHTML = strHTML & "border-bottom: 1px solid #999999;" & vbcrlf 
strHTML = strHTML & "border-left: 1px solid #999999;" & vbcrlf 
strHTML = strHTML & "padding-top: 0px;" & vbcrlf 
strHTML = strHTML & "padding-right: 0px;" & vbcrlf 
strHTML = strHTML & "padding-bottom: 0px;" & vbcrlf 
strHTML = strHTML & "padding-left: 0px;" & vbcrlf 
strHTML = strHTML & "}" & vbcrlf 
strHTML = strHTML & "body {" & vbcrlf 
strHTML = strHTML & "margin-left: 5px;" & vbcrlf 
strHTML = strHTML & "margin-top: 5px;" & vbcrlf 
strHTML = strHTML & "margin-right: 0px;" & vbcrlf 
strHTML = strHTML & "margin-bottom: 10px;" & vbcrlf 
strHTML = strHTML & "" & vbcrlf 
strHTML = strHTML & "table {" & vbcrlf 
strHTML = strHTML & "border: thin solid #000000;" & vbcrlf 
strHTML = strHTML & "}" & vbcrlf 
strHTML = strHTML & "-->" & vbcrlf 
strHTML = strHTML & "</style>" & vbcrlf 
strHTML = strHTML & "</head>" & vbcrlf 
strHTML = strHTML & "<body>" & vbcrlf 
 
 'html report title table
strHTML = strHTML & "<table width='50%'>" & vbcrlf 
strHTML = strHTML & "<tr bgcolor='#CCCCCC'>" & vbcrlf 
strHTML = strHTML & "<td colspan='7' height='25' align='center'>" & vbcrlf 
strHTML = strHTML & "<font face='tahoma' color='#003399' size='2'><strong>" & strReportTitle & "</strong></font>" & vbcrlf 
strHTML = strHTML & "</td>" & vbcrlf 
strHTML = strHTML & "</tr>" & vbcrlf 
strHTML = strHTML & "</table>" & vbcrlf 
 

'Query Server for drive details
For sCount = 1 to UBound(ServerList)
	strComputer = ServerList(sCount)
	wscript.echo strComputer
	
	'Start the html table
    strHTML = strHTML & "<table width='50%'><tbody>" & vbcrlf 
    strHTML = strHTML & "<tr bgcolor='#CCCCCC'>" & vbcrlf 
    strHTML = strHTML & "<td width='50%' align='center' colSpan=6><font face='tahoma' color='#003399' size='2'><strong>" & StrComputer & "</strong></font></td>" & vbcrlf 
    strHTML = strHTML & "</tr>" & vbcrlf 
	strHTML = strHTML & "<tr bgcolor=#CCCCCC>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Drive / Mount</td>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Total Capacity (in GB)</td>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Used Capacity (in GB)</td>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Free Space (in GB)</td>" & vbcrlf 
	strHTML = strHTML & "<td width='20%' align='center'>Freespace %</td>" & vbcrlf 
    strHTML = strHTML & "</tr>" & vbcrlf 
	
	'use WMI to get the disk information
    Set objWMIService = GetObject("winmgmts:\\" & strComputer & "\root\cimv2") 
    Set colDisks = objWMIService.ExecQuery("Select * from Win32_LogicalDisk Where DriveType = " & HARD_DISK & "") 
 
	'Starting the loop to gather values from all Hard Drives 
	For Each objDisk in colDisks 
		'Get the data
		TotSpace=Round(((objDisk.Size)/1073741824),2) 
		FrSpace=Round(objDisk.FreeSpace/1073741824,2) 
		FrPercent=Round((FrSpace / TotSpace)*100,0) 
		UsSpace=Round((TotSpace - FrSpace),2) 
		Drv=objDisk.DeviceID 
					
		'Write data to history database.
		strSQL = "INSERT INTO DiskSpaceHistory (RunDate,ServerName,Drive,TotalSpace,UsedSpace,FreeSpace)VALUES("
		strSQL = strSQL & "'" & year(strRunDateString) & "-" & Month(strRunDateString) & "-" & Day(strRunDateString) & " 00:00:00'"
		strSQL = strSQL & ",'" & lcase(strComputer) & "'"
		strSQL = strSQL & ",'" & Drv & "'"
		strSQL = strSQL & "," & TotSpace 
		strSQL = strSQL & "," & UsSpace
		strSQL = strSQL & "," & FrSpace
		strSQL = strSQL & ")"
		WriteDB "CHDC-CLS-DHSQL9\DEV", "MIS_Admins", strSQL
		
		'Build the next row in the html table
		If FrPercent > 20 Then 
			Green = Green + 1
			strHTML = strHTML & "<tr><td align=center>" & Drv & "</td><td align=center>" & TotSpace & "</td><td align=center>" & UsSpace & "</td><td align=center>" & FrSpace & "</td><td BGCOLOR='#00FF00' align=center>" & FrPercent & "%" &"</td></tr>" 
		ElseIf FrPercent < 10 Then 
			Red = Red + 1
			strHTML = strHTML & "<tr><td align=center>" & Drv & "</td><td align=center>" & TotSpace & "</td><td align=center>" & UsSpace & "</td><td align=center>" & FrSpace & "</td><td bgcolor='#FF0000' align=center>" & FrPercent & "%" &"</td></tr>" 
		Else 
			Yellow = Yellow + 1
			strHTML = strHTML & "<tr><td align=center>" & Drv & "</td><td align=center>" & TotSpace & "</td><td align=center>" & UsSpace & "</td><td align=center>" & FrSpace & "</td><td bgcolor='#FBB917' align=center>" & FrPercent & "%" &"</td></tr>" 
		End If 
	Next 
	
	'Finish the html table
    strHTML = strHTML & "<tr>" & vbcrlf 
    strHTML = strHTML & "<td width='50%' colSpan=6>&nbsp;</td>" & vbcrlf 
    strHTML = strHTML & "</tr>" & vbcrlf 
    strHTML = strHTML & "</body></table>" & vbcrlf 
Next
'Finish the html page
strHTML = strHTML & "</body></html>" & vbcrlf 

'Write html output to history file
strFileName = strCurDir & "\Logs\Server_List_" & GetDateString(now(),10) & ".html"
WriteFileData strHTML, strFileName, "Append", True

'Send Email to list
SendMail strFromEmailAddress, strToEmailAddress, strEmailSubject & " G:" & Green & " Y:" & Yellow & " R:" & Red, strHTML, strFromSMTPServer, strEmailAttachment
wscript.quit
'**************************************************************************************************************
'*                                             Routines Below Here                                            *
'**************************************************************************************************************
Sub WriteDB(strServer, strDB, strSQL)
	'Insert, Update and Delete only
	If DebugFlag Then
		on error goto 0
	Else
		on error resume next
	End If
	If SQLDebugflg then Wscript.echo "************************************************************************"
	If SQLDebugflg then Wscript.echo "Function WriteDB"
	If SQLDebugflg then Wscript.echo "Database Server: " & strServer
	If SQLDebugflg then Wscript.echo "Database: " & strDB
	If SQLDebugflg then Wscript.echo "SQL: " & strSQL
	strDBConnect = "Driver={SQL Server};Server=" & strServer & ";Database=" & Replace(Replace(strDB,"[",""),"]","") & ";Trusted_Connection=yes;"
	If SQLDebugflg then Wscript.echo strDBConnect
    Const adOpenStatic = 3
    Const adLockOptimistic = 3
    Const adUseClient = 3
    Set cn = CreateObject("ADODB.Connection")
    cn.Open strDBConnect
	cn.commandTimeout = 120
    Set rs = CreateObject("ADODB.Recordset")
    rs.CursorLocation = adUseClient
    rs.Open strSQL, cn, adOpenStatic, adLockOptimistic
    Set rs = Nothing
    Set cn = Nothing
	If err.number <> 0 Then
		strMessage = Now() & vbtab & "Function WriteDB: "  & vbtab & err.number & vbtab & Err.Description 
		WriteFileData strMessage & vbcrlf, strLogFile,"Append"
		err.clear
	End If
End Sub

Sub SendMail(strEmailFrom, strEmailTo, strEmailSubject, strMessage, strFromEmailAddress, strEmailAttachment)
	If DebugFlag Then
        on error goto 0
    Else
       	on error resume next
    End If
	If VerboseDebugFlag Then
		strMessageVerboseLog = Now() & vbtab & "Sub SendMail: Begin " & strEmailTo & " " & strEmailSubject
		WriteFileData strMessageVerboseLog, strLogFile, "Append", True
	End if
    Set objEmail = CreateObject("CDO.Message")
	objEmail.From = strEmailFrom
	objEmail.To = strEmailTo
	objEmail.Subject = strEmailSubject
	objEmail.HTMLbody = strMessage
	'objEmail.Textbody = strMessage
	If Len(strEmailAttachment) > 0 Then	objEmail.AddAttachment strEmailAttachment
	objEmail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2
	objEmail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/smtpserver") = strFromEmailAddress
	objEmail.Configuration.Fields.Item("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = 25
	objEmail.Configuration.Fields.Update
	objEmail.Send
	Set objEmail = Nothing
	If err.number <> 0 Then
		strMessage = Now() & vbtab & "Sub SendMail: " & vbtab & Err.number & vbtab & Err.Description   
		WriteFileData strMessage,strErrorLogs, "Append", True
		MsgBox(strMessage & vbCRLF & "Check LOG File in " & vbCRLF & strLogFile)
		err.clear
		wscript.quit
	End IF
End Sub

Function WriteFileData(text, strFileName, strMode, UniCodeDummy)
	'Write File Data
	If DebugFlag Then
		on error goto 0
	Else
		on error resume next
	End If
	Const Unicode = -1
	Const ForReading = 1
	Const ForWriting = 2
	Const ForAppending = 8
	Set objFSO = CreateObject("Scripting.FileSystemObject")
	If objFSO.FileExists(strFileName) Then
   	
	Else
   		Set objFile = objFSO.CreateTextFile(strFileName, True)
	End If 
	set objFile = nothing

	If  ucase(strMode) = "APPEND" Then
		Set objTextFile = objFSO.OpenTextFile(strFileName, ForAppending, True, Unicode)
	Else
		Set objTextFile = objFSO.OpenTextFile(strFileName, ForWriting, True, Unicode)
	End If
	'Writes strText every time you run this VBScript
	objTextFile.Write text
	objTextFile.Close
End Function

Function GetDateString(dtDateTime,numReturnLength)
	'output yyyymmddhhmmss
	If DebugFlag Then
		on error goto 0
	Else
		on error resume next
	End If
	strYear = Year(dtDateTime)
	strMonth = Month(dtDateTime)
	If Len(strMonth) < 2 then strMonth = "0" & strMonth
	strDay = Day(dtDateTime)
	If Len(strDay) < 2 then strDay = "0" & strDay
	strHour = Hour(dtDateTime)
	If Len(strHour) < 2 then strHour = "0" & strHour
	strMinute = Minute(dtDateTime)
	If Len(strMinute) < 2 Then strMinute = "0" & strMinute
	strSecond = Second(dtDateTime)
	If Len(strSecond) < 2 Then strSecond = "0" & strSecond
	GetDateString = Left(strYear & strMonth & strDay & strHour & strMinute & strSecond,numReturnLength)
	If err.number <> 0 Then
		strMessage = Now() & vbtab & "Function GetDateString: "  & vbtab & err.number & vbtab & Err.Description 
		WriteFileData strMessage & vbcrlf, strErrorLogs,"Append", True
		err.clear
	End If
End Function