# Grant-BatchLogonRight.ps1
# Simple script to grant "Log on as batch job" right

param(
    [string]$ServiceAccount,
    [string]$ComputerName = $env:COMPUTERNAME
)

$ErrorActionPreference = 'Stop'
Write-Host "PARAMs:"
Write-Host "  ServiceAccount: $ServiceAccount"
Write-Host "  ComputerName  : $ComputerName"

if (-not $PSBoundParameters.ContainsKey('ComputerName') -or $ComputerName -eq $env:COMPUTERNAME) {
    # Run locally
    Write-Host "Processing local server..."
    
    # Get the account SID
    $account = New-Object System.Security.Principal.NTAccount($ServiceAccount)
    $sid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value

    # Create temp files
    # $export = "$env:TEMP\export.inf"
    # $import = "$env:TEMP\import.inf"
    $export = "C:\AJ\Scripts\DiskMonitor\PermissionsGrant\TempFiles\export_LOCAL.inf"
    $import = "C:\AJ\Scripts\DiskMonitor\PermissionsGrant\TempFiles\import_LOCAL.inf"

    # Export current policy
    secedit /export /cfg $export /quiet

    # Read the file
    $content = Get-Content $export

	# Find the batch logon line or add it
	$found = $false
	for ($i = 0; $i -lt $content.Length; $i++) {
		if ($content[$i] -match "SeBatchLogonRight") {
			if ($content[$i] -like "*$sid*") {
				Write-Host "$Account on $Computer already has log on as batch job permissions."
				$found = $true
			}
			else {
				Write-Host "$Account on $Computer did not originally have log on as batch job permissions.  Adding now:"
				$content[$i] = $content[$i] + ",*$sid"
			}
			break
		}
	}

    # Write and import
    $content | Out-File $import -Encoding Unicode
    secedit /configure /db $env:windir\security\local.sdb /cfg $import /quiet

    # Cleanup
    # Remove-Item $export, $import

    Write-Host "Done. $ServiceAccount can now log on as batch job."
    
} else {
	# Run remotely
	Write-Host "Processing remote server: $ComputerName"
	$successTestConnection = Test-Connection $ComputerName -Count 1 -Quiet
	if ($successTestConnection) {
		try {
			$result = Invoke-Command -ComputerName $ComputerName -ScriptBlock {
				param($Account, $Computer)
				
				try {
					# Get the account SID
					$account = New-Object System.Security.Principal.NTAccount($Account)
					$sid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value
					Write-Host "sid: $sid"
	
					# Create temp files
					$export = "C:\export_$Computer.inf"
					$import = "C:\import_$Computer.inf"
	
					# Export current policy
					secedit /export /cfg $export /quiet
	
					# Read the file
					$content = Get-Content $export
	
					# Find the batch logon line or add it
					$found = $false
					for ($i = 0; $i -lt $content.Length; $i++) {
						if ($content[$i] -match "SeBatchLogonRight") {
							if ($content[$i] -like "*$sid*") {
								Write-Host "$Account on $Computer already has log on as batch job permissions."
								$found = $true
							}
							else {
								Write-Host "$Account on $Computer did not originally have log on as batch job permissions.  Adding now:"
								$content[$i] = $content[$i] + ",*$sid"
							}
							break
						}
					}
	
					# Write and import
					$content | Out-File $import -Encoding Unicode
					secedit /configure /db $env:windir\security\local.sdb /cfg $import /quiet
	
					# Cleanup
					# Remove-Item $export, $import -ErrorAction SilentlyContinue
					
					# DCOM Permissions: Run this directly on each target server
					Write-Host "Setting DCOM permissions for $account"
					$account = "SU.lan\svc_diskmon";
					$appId = "{8BC3F05E-D86B-11D0-A075-00C04FB68820}";
					$ntAccount = New-Object System.Security.Principal.NTAccount($account);
					$sid = $ntAccount.Translate([System.Security.Principal.SecurityIdentifier]);
					$reg = [Microsoft.Win32.Registry]::LocalMachine;
					$key = $reg.OpenSubKey("SOFTWARE\Classes\AppID\$appId", $true);
					$currentPerm = $key.GetValue("LaunchPermission");
					$sd = New-Object System.Security.AccessControl.RawSecurityDescriptor($currentPerm, 0);
					$accessRule = New-Object System.Security.AccessControl.CommonAce([System.Security.AccessControl.AceFlags]::None, [System.Security.AccessControl.AceQualifier]::AccessAllowed, 15, $sid, $false, $null);  #not 11
					$sd.DiscretionaryAcl.InsertAce($sd.DiscretionaryAcl.Count, $accessRule);
					$newPerm = New-Object byte[] $sd.BinaryLength;
					$sd.GetBinaryForm($newPerm, 0);
					$key.SetValue("LaunchPermission", $newPerm, "Binary");
					$key.Close();
					Write-Host "DCOM permissions set for $account"
	
					# Return success
					return $true
					
				}
				catch {
					Write-Error "Error in scriptblock: $($_.Exception.Message)"
					return $false
				}
				
			} -ArgumentList $ServiceAccount, $ComputerName
			
			if ($result) {
				Write-Host "$ComputerName completed successfully" -ForegroundColor Green
			} else {
				Write-Host "$ComputerName failed" -ForegroundColor Red
			}
		}
		catch {
			Write-Host "$ComputerName failed with error: $($_.Exception.Message)" -ForegroundColor Red
		}
	} else {
		Write-Warning "Cannot reach server: $ComputerName"
	}
}
