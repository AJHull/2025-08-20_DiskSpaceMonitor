# Grant-BatchLogonRight.ps1
# Simple script to grant "Log on as batch job" right

param(
    [string]$ServiceAccount,
    [string]$ComputerName = $env:COMPUTERNAME
)

$ErrorActionPreference = 'Stop'
Write-Host "PARAMs:"
Write-Host "  ServiceAccount: $ServiceAccount"
Write-Host "  ComputerName  : $ComputerName"

# Run remotely
Write-Host "Processing remote server: $ComputerName"
$successTestConnection = Test-Connection $ComputerName -Count 1 -Quiet
if ($successTestConnection) {
	try {
		$result = Invoke-Command -ComputerName $ComputerName -ScriptBlock {
			param($Account, $Computer)
			
			try {
				# Get the account SID
				$account = New-Object System.Security.Principal.NTAccount($Account)
				$sid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value

				# Create temp files
				$export = "C:\export_$Computer.inf"
				$import = "C:\import_$Computer.inf"

				# Export current policy
				secedit /export /cfg $export /quiet

				# Read the file
				$content = Get-Content $export

				# Find the batch logon line or add it
				$found = $false
				for ($i = 0; $i -lt $content.Length; $i++) {
					if ($content[$i] -match "SeBatchLogonRight") {
						if ($content[$i] -notlike "*$sid*") {
							$content[$i] = $content[$i] + ",*$sid"
						}
						$found = $true
						break
					}
				}

				# Add new line if not found
				if (-not $found) {
					Write-Host "$Account on $Computer did not originally have log on as batch job permissions.  Adding now:"
					$content += "SeBatchLogonRight = *$sid"
				}
				else {
					Write-Host "$Account on $Computer already has log on as batch job permissions."
				}

				# Write and import
				$content | Out-File $import -Encoding Unicode
				secedit /configure /db $env:windir\security\local.sdb /cfg $import /quiet

				# Cleanup
				Remove-Item $export, $import -ErrorAction SilentlyContinue

				# Return success
				return $true
				
			}
			catch {
				Write-Error "Error in scriptblock: $($_.Exception.Message)"
				return $false
			}
			
		} -ArgumentList $ServiceAccount, $ComputerName
		
		if ($result) {
			Write-Host "$ComputerName completed successfully" -ForegroundColor Green
		} else {
			Write-Host "$ComputerName failed" -ForegroundColor Red
		}
	}
	catch {
		Write-Host "$ComputerName failed with error: $($_.Exception.Message)" -ForegroundColor Red
	}
} else {
	Write-Warning "Cannot reach server: $ComputerName"
}
