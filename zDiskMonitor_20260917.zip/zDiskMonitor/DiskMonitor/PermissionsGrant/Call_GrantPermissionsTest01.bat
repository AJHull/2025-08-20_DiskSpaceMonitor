PowerShell -NoProfile -ExecutionPolicy Unrestricted -File ".\GrantPermissionsTest01.ps1"
@REM cscript CompleteWMISetup.vbs "SU.lan\svc_diskmon" SQL2017.su.lan "S-1-5-21-2359056441-1596927414-2997967061-4672"

@REM cscript CompleteWMISetup.vbs "SU.lan\svc_diskmon" BLD2.su.lan "S-1-5-21-2359056441-1596927414-2997967061-4672"