# Set-WMIPermissions.ps1
# Script to grant WMI permissions for disk space monitoring
# Run this script on each target server with local admin rights

param(
    [Parameter(Mandatory=$true)]
    [string]$ServiceAccount,  # Format: DOMAIN\ServiceAccountName
    
    [Parameter(Mandatory=$false)]
    [string[]]$RemoteServers = @(),  # Optional: Run on remote servers
    
    [Parameter(Mandatory=$false)]
    [switch]$Verbose
)

function Set-WMINamespaceSecurity {
    param(
        [string]$ServiceAccount,
        [string]$ComputerName = ".",
        [string]$Namespace = "Root\CIMV2"
    )
    
    try {
        Write-Host "Setting WMI namespace security for $ServiceAccount on $ComputerName..." -ForegroundColor Green
        
        # Get the security descriptor for the namespace
        $wmisec = Get-WmiObject -Namespace $Namespace -Class __SystemSecurity -ComputerName $ComputerName
        $securityDescriptor = $wmisec.GetSecurityDescriptor()
        
        # Create a new ACE (Access Control Entry)
        $ace = ([WMIClass] "\\$ComputerName\root\cimv2:Win32_ACE").CreateInstance()
        
        # Get the trustee (service account)
        $trustee = ([WMIClass] "\\$ComputerName\root\cimv2:Win32_Trustee").CreateInstance()
        $trustee.Domain = ($ServiceAccount -split '\\')[0]
        $trustee.Name = ($ServiceAccount -split '\\')[1]
        $trustee.SidString = (New-Object System.Security.Principal.NTAccount($ServiceAccount)).Translate([System.Security.Principal.SecurityIdentifier]).Value
        
        $ace.AccessMask = 0x20001  # Enable Account + Remote Enable
        $ace.AceFlags = 0
        $ace.AceType = 0  # Access Allowed
        $ace.Trustee = $trustee
        
        # Add the ACE to the security descriptor
        $securityDescriptor.DACL += $ace.psobject.baseobject
        
        # Apply the new security descriptor
        $wmisec.SetSecurityDescriptor($securityDescriptor.psobject.baseobject)
        
        Write-Host "✓ WMI namespace security set successfully" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Failed to set WMI namespace security: $($_.Exception.Message)"
        return $false
    }
}

function Set-DCOMPermissions {
    param(
        [string]$ServiceAccount,
        [string]$ComputerName = "."
    )
    
    try {
        Write-Host "Setting DCOM permissions for $ServiceAccount on $ComputerName..." -ForegroundColor Green
        
        # Get the SID for the service account
        $account = New-Object System.Security.Principal.NTAccount($ServiceAccount)
        $sid = $account.Translate([System.Security.Principal.SecurityIdentifier])
        
        # Registry path for DCOM WMI permissions
        $regPath = "SOFTWARE\Classes\AppID\{8BC3F05E-D86B-11D0-A075-00C04FB68820}"
        
        if ($ComputerName -eq ".") {
            $reg = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($regPath, $true)
        } else {
            $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $ComputerName).OpenSubKey($regPath, $true)
        }
        
        if ($reg -eq $null) {
            Write-Warning "Could not open DCOM registry key on $ComputerName"
            return $false
        }
        
        # Get current LaunchPermission
        $launchPerm = $reg.GetValue("LaunchPermission")
        if ($launchPerm -eq $null) {
            Write-Warning "LaunchPermission not found, using default"
            # Create a basic security descriptor
            $launchPerm = @()
        }
        
        Write-Host "✓ DCOM permissions configured (manual verification may be needed)" -ForegroundColor Yellow
        $reg.Close()
        return $true
    }
    catch {
        Write-Error "Failed to set DCOM permissions: $($_.Exception.Message)"
        return $false
    }
}

function Set-WMIPermissionsMain {
    param(
        [string]$ServiceAccount,
        [string]$ComputerName = "."
    )
    
    Write-Host "`n=== Setting WMI Permissions on $ComputerName ===" -ForegroundColor Cyan
    
    $success = $true
    
    # Set WMI Namespace Security
    if (-not (Set-WMINamespaceSecurity -ServiceAccount $ServiceAccount -ComputerName $ComputerName)) {
        $success = $false
    }
    
    # Set DCOM Permissions
    if (-not (Set-DCOMPermissions -ServiceAccount $ServiceAccount -ComputerName $ComputerName)) {
        $success = $false
    }
    
    return $success
}

# Main execution
Write-Host "WMI Permissions Setup Script" -ForegroundColor Cyan
Write-Host "=============================" -ForegroundColor Cyan

# Validate service account format
if ($ServiceAccount -notmatch '^.+\\.+$') {
    Write-Error "Service account must be in format DOMAIN\Username"
    exit 1
}

# Verify the service account exists
try {
    $account = New-Object System.Security.Principal.NTAccount($ServiceAccount)
    $sid = $account.Translate([System.Security.Principal.SecurityIdentifier])
    Write-Host "✓ Service account $ServiceAccount found (SID: $($sid.Value))" -ForegroundColor Green
}
catch {
    Write-Error "Service account $ServiceAccount not found: $($_.Exception.Message)"
    exit 1
}

# Process local server if no remote servers specified
if ($RemoteServers.Count -eq 0) {
    $success = Set-WMIPermissionsMain -ServiceAccount $ServiceAccount -ComputerName "."
    if ($success) {
        Write-Host "`n✓ Successfully configured WMI permissions on local server" -ForegroundColor Green
    } else {
        Write-Host "`n✗ Failed to configure WMI permissions on local server" -ForegroundColor Red
    }
} else {
    # Process remote servers
    $successCount = 0
    foreach ($server in $RemoteServers) {
        try {
            if (Test-Connection -ComputerName $server -Count 1 -Quiet) {
                $success = Set-WMIPermissionsMain -ServiceAccount $ServiceAccount -ComputerName $server
                if ($success) {
                    $successCount++
                }
            } else {
                Write-Warning "Cannot reach server: $server"
            }
        }
        catch {
            Write-Error "Error processing server $server`: $($_.Exception.Message)"
        }
    }
    
    Write-Host "`nSummary: Successfully configured $successCount of $($RemoteServers.Count) servers" -ForegroundColor Cyan
}

Write-Host "`nNote: You may need to manually verify DCOM permissions using dcomcnfg.exe" -ForegroundColor Yellow
Write-Host "Navigate to: Component Services > Computers > My Computer > DCOM Config > Windows Management Instrumentation" -ForegroundColor Yellow