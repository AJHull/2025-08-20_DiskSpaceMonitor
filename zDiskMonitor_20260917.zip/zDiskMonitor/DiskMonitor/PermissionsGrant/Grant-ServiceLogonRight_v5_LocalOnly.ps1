# Grant-BatchLogonRight.ps1
# Simple script to grant "Log on as batch job" right

param(
    [string]$ServiceAccount
)

# Get the account SID
$account = New-Object System.Security.Principal.NTAccount($ServiceAccount)
$sid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value

# Create temp files
$export = "C:\AJ\Scripts\DiskMonitor\PermissionsGrant\TempFiles\export.inf"
$import = "C:\AJ\Scripts\DiskMonitor\PermissionsGrant\TempFiles\import.inf"

# Export current policy
secedit /export /cfg $export /quiet

# Read the file
$content = Get-Content $export

# Find the batch logon line or add it
$found = $false
for ($i = 0; $i -lt $content.Length; $i++) {
    if ($content[$i] -match "SeBatchLogonRight") {
        if ($content[$i] -notlike "*$sid*") {
            $content[$i] = $content[$i] + ",*$sid"
        }
        $found = $true
        break
    }
}

# Add new line if not found
if (-not $found) {
    $content += "SeBatchLogonRight = *$sid"
}

# Write and import
$content | Out-File $import -Encoding Unicode
secedit /configure /db $env:windir\security\local.sdb /cfg $import /quiet

# Cleanup
# Remove-Item $export, $import

Write-Host "Done. $ServiceAccount can now log on as batch job."