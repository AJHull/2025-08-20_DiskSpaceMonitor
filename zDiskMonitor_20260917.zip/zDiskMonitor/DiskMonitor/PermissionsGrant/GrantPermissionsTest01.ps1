# foreach ($group in Get-LocalGroup) {
# [PSCustomObject\]@{
# Group = $[group.Name](https://group.Name)
# User  = (($group | Get-LocalGroupMember).Name | Out-String).Trim()
#    }|fl
# }

# Get-LocalGroup
# Get-LocalGroupMember -Group "Administrators"
# Grant-UserRight -Account "SU.lan\svc_diskmon" -Right "SeBatchLogonRight"

# .\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon"
#.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL2017.su.lan"

# SUCCESS
# .\TestPSSyntax03.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL2017.su.lan"

# 1. Set WMI permissions on all target servers
# $servers = @("SQL20172.su.lan")  #@("SERVER01", "SERVER02", "SERVER03")
# .\Set-WMIPermissions.ps1 -ServiceAccount "SU\svc-diskmon" -RemoteServers $servers -Verbose

.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL2017.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL2019.su.lan"

.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "AIRTest2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "AIRTest2-Clone.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "AJ2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "BDame-2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "BLD2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "BUS2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "BUS3.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "DC11.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "DC12.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Dev-SQLMon-DB.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Dev-SQLMon-Svc.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "DEV-TEST-BJK1.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "DEV-TS2019.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "DEV-TS-SQL2019.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Dev-WebUI-Kim.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Dev-WebUI-QA.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Dev-WebUI-Stagi.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Dev-WebUI-TRN.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "DHCP1.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "DHCP2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "ES2016.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "FS1-2019.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "FTP2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "FTP2-Clone.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Kim-2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Laura2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Lin-2.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL_CEN_CTD.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL-2008R2-NS.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL2012.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL2014.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL2017.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL2019.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SQL2022.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "SUW-VM22A.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "swprsrvr2022.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "Swpr-test-2022.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "tfs3.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "TFS4.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "TS2012.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "TS2016.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "TS2022.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "US18.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "WG2016.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "WG2019.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "WIN-OE9LNRVJ32T.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "WS4.su.lan"
.\Grant-ServiceLogonRight.ps1 -ServiceAccount "SU.lan\svc_diskmon" -ComputerName "WS4-Clone.su.lan"
