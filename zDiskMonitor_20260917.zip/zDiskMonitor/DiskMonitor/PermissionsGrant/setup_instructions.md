# Disk Space Monitoring - Permission Setup Instructions

## Prerequisites
- Domain Administrator or Local Administrator rights on target servers
- PowerShell execution policy set to allow script execution
- Service account created (e.g., `DOMAIN\svc-diskmon`)

## Step-by-Step Setup Process

### Step 1: Prepare Your Environment

1. **Create a service account** (if not already done):
   ```powershell
   # Example: Create service account in Active Directory
   New-ADUser -Name "svc-diskmon" -SamAccountName "svc-diskmon" -UserPrincipalName "svc-diskmon@yourdomain.com" -AccountPassword (ConvertTo-SecureString "ComplexPassword123!" -AsPlainText -Force) -Enabled $true -PasswordNeverExpires $true
   ```

2. **Prepare your server list**:
   ```powershell
   # Create an array of target servers
   $servers = @("SERVER01", "SERVER02", "SERVER03", "SERVER04")
   ```

3. **Set PowerShell execution policy** (if needed):
   ```powershell
   Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```

### Step 2: Set Up WMI Permissions

**For single server (run locally on target server):**
```powershell
.\Set-WMIPermissions.ps1 -ServiceAccount "YOURDOMAIN\svc-diskmon"
```

**For multiple servers (run from management server):**
```powershell
# Define your servers
$servers = @("SERVER01", "SERVER02", "SERVER03")

# Run the script against multiple servers
.\Set-WMIPermissions.ps1 -ServiceAccount "YOURDOMAIN\svc-diskmon" -RemoteServers $servers
```

**Alternative: Use Invoke-Command for remote execution:**
```powershell
$servers = @("SERVER01", "SERVER02", "SERVER03")
$serviceAccount = "YOURDOMAIN\svc-diskmon"

Invoke-Command -ComputerName $servers -ScriptBlock {
    param($Account)
    # Copy the Set-WMIPermissions.ps1 script to each server first
    & "C:\Scripts\Set-WMIPermissions.ps1" -ServiceAccount $Account
} -ArgumentList $serviceAccount
```

### Step 3: Set Up File System Permissions

**This should be run on the server where the VBScript will execute:**

```powershell
# Single server setup
.\Set-FileSystemPermissions.ps1 -ServiceAccount "YOURDOMAIN\svc-diskmon" -ScriptPath "C:\Scripts\DiskSpace"

# Multiple servers (if running the script from multiple locations)
$servers = @("MGMT01", "MGMT02")  # Servers where the script will run
.\Set-FileSystemPermissions.ps1 -ServiceAccount "YOURDOMAIN\svc-diskmon" -ScriptPath "C:\Scripts\DiskSpace" -RemoteServers $servers
```

### Step 4: Verify Permissions

**Test WMI access:**
```powershell
# Test WMI connectivity as the service account
$cred = Get-Credential "YOURDOMAIN\svc-diskmon"
Get-WmiObject -Class Win32_LogicalDisk -ComputerName "SERVER01" -Credential $cred
```

**Test file access:**
```powershell
# Test file system access
Test-Path "C:\Scripts\DiskSpace\Logs" -PathType Container
```

## Complete Setup Example

Here's a complete example script to set up permissions across multiple servers:

```powershell
# Complete setup script
param(
    [string]$ServiceAccount = "YOURDOMAIN\svc-diskmon",
    [string]$ScriptPath = "C:\Scripts\DiskSpace",
    [string[]]$TargetServers = @("SERVER01", "SERVER02", "SERVER03"),
    [string]$ManagementServer = "MGMT01"
)

Write-Host "Starting permission setup for disk space monitoring..." -ForegroundColor Cyan

# Step 1: Set WMI permissions on all target servers
Write-Host "`n=== Setting WMI Permissions ===" -ForegroundColor Yellow
foreach ($server in $TargetServers) {
    Write-Host "Processing $server..." -ForegroundColor Green
    Invoke-Command -ComputerName $server -ScriptBlock {
        param($Account, $ScriptPath)
        & "$ScriptPath\Set-WMIPermissions.ps1" -ServiceAccount $Account
    } -ArgumentList $ServiceAccount, $ScriptPath
}

# Step 2: Set file system permissions on management server
Write-Host "`n=== Setting File System Permissions ===" -ForegroundColor Yellow
Invoke-Command -ComputerName $ManagementServer -ScriptBlock {
    param($Account, $ScriptPath)
    & "$ScriptPath\Set-FileSystemPermissions.ps1" -ServiceAccount $Account -ScriptPath $ScriptPath
} -ArgumentList $ServiceAccount, $ScriptPath

Write-Host "`n✓ Permission setup complete!" -ForegroundColor Green
```

## Manual Verification Steps

### Verify WMI Permissions Manually:

1. **Open Component Services** (`dcomcnfg.exe`) on target server
2. Navigate to: **Component Services > Computers > My Computer > DCOM Config**
3. Find **"Windows Management Instrumentation"**
4. Right-click > **Properties > Security tab**
5. Verify your service account has:
   - **Launch and Activation Permissions**: Local Launch, Remote Launch, Local Activation, Remote Activation
   - **Access Permissions**: Local Access, Remote Access

### Verify WMI Namespace Security:

1. **Open WMI Control** (`wmimgmt.msc`)
2. Right-click **"WMI Control (Local)" > Properties**
3. Go to **Security tab**
4. Select **"Root\CIMV2" > Security button**
5. Verify your service account has:
   - **Enable Account**
   - **Remote Enable**

## Troubleshooting

### Common Issues:

1. **"Access Denied" errors:**
   - Verify service account exists and is spelled correctly
   - Check if account is locked or disabled
   - Ensure you have admin rights when running the scripts

2. **WMI connection failures:**
   - Check Windows Firewall settings
   - Verify DCOM permissions were applied correctly
   - Test with `winrm quickconfig` on target servers

3. **File permission issues:**
   - Verify the script path exists
   - Check if the Logs directory was created
   - Test file creation manually with the service account

### Testing Commands:

```powershell
# Test WMI access
$cred = Get-Credential "YOURDOMAIN\svc-diskmon"
Get-WmiObject -Class Win32_LogicalDisk -ComputerName "SERVER01" -Credential $cred | Select-Object DeviceID, Size, FreeSpace

# Test file access (run as service account)
New-Item -Path "C:\Scripts\DiskSpace\Logs\test.txt" -ItemType File -Force
Remove-Item -Path "C:\Scripts\DiskSpace\Logs\test.txt" -Force
```

## Notes

- These scripts create the minimum required permissions
- Always test in a non-production environment first
- Consider using Group Managed Service Accounts (gMSA) for enhanced security
- Document the service account and permissions for future reference
- The scripts include error handling and verbose output for troubleshooting