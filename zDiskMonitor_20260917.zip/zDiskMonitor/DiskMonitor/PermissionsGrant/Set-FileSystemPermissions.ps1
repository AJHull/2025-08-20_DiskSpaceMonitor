# Set-FileSystemPermissions.ps1
# Script to set up file system permissions for disk space monitoring script
# Run this on the server where the VBScript will execute

param(
    [Parameter(Mandatory=$true)]
    [string]$ServiceAccount,  # Format: DOMAIN\ServiceAccountName
    
    [Parameter(Mandatory=$true)]
    [string]$ScriptPath,      # Path where the VBScript will be located
    
    [Parameter(Mandatory=$false)]
    [string[]]$RemoteServers = @(),  # Optional: Run on remote servers
    
    [Parameter(Mandatory=$false)]
    [switch]$CreateDirectories = $true
)

function Set-DirectoryPermissions {
    param(
        [string]$Path,
        [string]$ServiceAccount,
        [string]$Permission,
        [string]$ComputerName = "."
    )
    
    try {
        # For remote servers, use UNC path
        if ($ComputerName -ne ".") {
            $Path = "\\$ComputerName\" + $Path.Replace(":", "$")
        }
        
        Write-Host "Setting $Permission permissions on: $Path" -ForegroundColor Green
        
        # Get current ACL
        $acl = Get-Acl -Path $Path
        
        # Create new access rule
        $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $ServiceAccount,
            $Permission,
            "ContainerInherit,ObjectInherit",
            "None",
            "Allow"
        )
        
        # Add the access rule to ACL
        $acl.SetAccessRule($accessRule)
        
        # Apply the ACL
        Set-Acl -Path $Path -AclObject $acl
        
        Write-Host "✓ Successfully set $Permission permissions for $ServiceAccount" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Failed to set permissions on $Path`: $($_.Exception.Message)"
        return $false
    }
}

function Create-DirectoryStructure {
    param(
        [string]$BasePath,
        [string]$ComputerName = "."
    )
    
    try {
        # For remote servers, use UNC path
        if ($ComputerName -ne ".") {
            $BasePath = "\\$ComputerName\" + $BasePath.Replace(":", "$")
        }
        
        Write-Host "Creating directory structure at: $BasePath" -ForegroundColor Green
        
        # Create base directory if it doesn't exist
        if (-not (Test-Path -Path $BasePath)) {
            New-Item -Path $BasePath -ItemType Directory -Force | Out-Null
            Write-Host "✓ Created base directory: $BasePath" -ForegroundColor Green
        }
        
        # Create Logs subdirectory
        $logsPath = Join-Path -Path $BasePath -ChildPath "Logs"
        if (-not (Test-Path -Path $logsPath)) {
            New-Item -Path $logsPath -ItemType Directory -Force | Out-Null
            Write-Host "✓ Created Logs directory: $logsPath" -ForegroundColor Green
        }
        
        return @{
            BasePath = $BasePath
            LogsPath = $logsPath
        }
    }
    catch {
        Write-Error "Failed to create directory structure: $($_.Exception.Message)"
        return $null
    }
}

function Set-FileSystemPermissionsMain {
    param(
        [string]$ServiceAccount,
        [string]$ScriptPath,
        [string]$ComputerName = "."
    )
    
    Write-Host "`n=== Setting File System Permissions on $ComputerName ===" -ForegroundColor Cyan
    
    $success = $true
    
    # Create directories if requested
    if ($CreateDirectories) {
        $directories = Create-DirectoryStructure -BasePath $ScriptPath -ComputerName $ComputerName
        if ($directories -eq $null) {
            return $false
        }
    } else {
        $directories = @{
            BasePath = $ScriptPath
            LogsPath = Join-Path -Path $ScriptPath -ChildPath "Logs"
        }
    }
    
    # Set permissions on base directory (Read & Execute)
    if (-not (Set-DirectoryPermissions -Path $directories.BasePath -ServiceAccount $ServiceAccount -Permission "ReadAndExecute" -ComputerName $ComputerName)) {
        $success = $false
    }
    
    # Set permissions on Logs directory (Modify)
    if (-not (Set-DirectoryPermissions -Path $directories.LogsPath -ServiceAccount $ServiceAccount -Permission "Modify" -ComputerName $ComputerName)) {
        $success = $false
    }
    
    return $success
}

function Test-ServiceAccountExists {
    param([string]$ServiceAccount)
    
    try {
        $account = New-Object System.Security.Principal.NTAccount($ServiceAccount)
        $sid = $account.Translate([System.Security.Principal.SecurityIdentifier])
        Write-Host "✓ Service account $ServiceAccount found (SID: $($sid.Value))" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Service account $ServiceAccount not found: $($_.Exception.Message)"
        return $false
    }
}

function Test-PathAccessible {
    param(
        [string]$Path,
        [string]$ComputerName = "."
    )
    
    try {
        if ($ComputerName -ne ".") {
            $testPath = "\\$ComputerName\" + $Path.Replace(":", "$")
        } else {
            $testPath = $Path
        }
        
        # Test if we can access the path
        if (Test-Path -Path $testPath -PathType Container) {
            Write-Host "✓ Path exists and is accessible: $testPath" -ForegroundColor Green
            return $true
        } elseif ($CreateDirectories) {
            Write-Host "○ Path will be created: $testPath" -ForegroundColor Yellow
            return $true
        } else {
            Write-Warning "Path does not exist: $testPath"
            return $false
        }
    }
    catch {
        Write-Error "Cannot access path $Path on $ComputerName`: $($_.Exception.Message)"
        return $false
    }
}

# Main execution
Write-Host "File System Permissions Setup Script" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan

# Validate parameters
if ($ServiceAccount -notmatch '^.+\\.+$') {
    Write-Error "Service account must be in format DOMAIN\Username"
    exit 1
}

if ([string]::IsNullOrWhiteSpace($ScriptPath)) {
    Write-Error "Script path cannot be empty"
    exit 1
}

# Verify the service account exists
if (-not (Test-ServiceAccountExists -ServiceAccount $ServiceAccount)) {
    exit 1
}

# Process local server if no remote servers specified
if ($RemoteServers.Count -eq 0) {
    Write-Host "`nProcessing local server..." -ForegroundColor Cyan
    
    # Test path accessibility
    if (-not (Test-PathAccessible -Path $ScriptPath)) {
        exit 1
    }
    
    $success = Set-FileSystemPermissionsMain -ServiceAccount $ServiceAccount -ScriptPath $ScriptPath -ComputerName "."
    
    if ($success) {
        Write-Host "`n✓ Successfully configured file system permissions on local server" -ForegroundColor Green
        Write-Host "  Base directory: $ScriptPath (ReadAndExecute)" -ForegroundColor Gray
        Write-Host "  Logs directory: $ScriptPath\Logs (Modify)" -ForegroundColor Gray
    } else {
        Write-Host "`n✗ Failed to configure file system permissions on local server" -ForegroundColor Red
        exit 1
    }
} else {
    # Process remote servers
    $successCount = 0
    $totalServers = $RemoteServers.Count
    
    foreach ($server in $RemoteServers) {
        Write-Host "`nProcessing server: $server" -ForegroundColor Cyan
        
        try {
            # Test connectivity
            if (-not (Test-Connection -ComputerName $server -Count 1 -Quiet)) {
                Write-Warning "Cannot reach server: $server"
                continue
            }
            
            # Test path accessibility
            if (-not (Test-PathAccessible -Path $ScriptPath -ComputerName $server)) {
                Write-Warning "Path not accessible on server: $server"
                continue
            }
            
            $success = Set-FileSystemPermissionsMain -ServiceAccount $ServiceAccount -ScriptPath $ScriptPath -ComputerName $server
            
            if ($success) {
                $successCount++
                Write-Host "✓ Successfully configured $server" -ForegroundColor Green
            } else {
                Write-Host "✗ Failed to configure $server" -ForegroundColor Red
            }
        }
        catch {
            Write-Error "Error processing server $server`: $($_.Exception.Message)"
        }
    }
    
    Write-Host "`nSummary: Successfully configured $successCount of $totalServers servers" -ForegroundColor Cyan
}

Write-Host "`nPermissions Summary:" -ForegroundColor Yellow
Write-Host "- Service Account: $ServiceAccount" -ForegroundColor Gray
Write-Host "- Script Directory: ReadAndExecute permissions" -ForegroundColor Gray
Write-Host "- Logs Directory: Modify permissions" -ForegroundColor Gray
Write-Host "`nThe service account can now:" -ForegroundColor Yellow
Write-Host "- Read the VBScript and configuration files" -ForegroundColor Gray
Write-Host "- Create and modify log files in the Logs directory" -ForegroundColor Gray
Write-Host "- Execute the VBScript from the script directory" -ForegroundColor Gray